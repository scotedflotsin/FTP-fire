package com.example.ftp_fire

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.ftp_fire.Utils.SharedPrefManager
import com.example.ftp_fire.databinding.ActivityDetailsBinding
import com.example.ftp_fire.databinding.ActivityMainBinding

class SettingScreen : AppCompatActivity() {
    private lateinit var binding: ActivityDetailsBinding
    private lateinit var sharedPrefManager: SharedPrefManager
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        enableEdgeToEdge()
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        sharedPrefManager = SharedPrefManager(this@SettingScreen)

        //setting path
        try {
            binding.username.setText(sharedPrefManager.getUsername());
            binding.password.setText(sharedPrefManager.getPassword());
            binding.requestpath.setText(sharedPrefManager.getUrl().toString());
        } catch (e: Exception) {
            Toast.makeText(this@SettingScreen, "Failed to load path!", Toast.LENGTH_SHORT).show()
        }
        binding.savedetails.setOnClickListener {
            if (binding.username.text.toString() != "" && binding.password.text.toString() != "") {
                updateCredentials(
                    binding.username.text.toString(),
                    binding.password.text.toString()
                );
            } else {
                Toast.makeText(this@SettingScreen, "Please enter credentials", Toast.LENGTH_SHORT)
                    .show();
            }
        }
        binding.copypath.setOnClickListener {
            copyPath(sharedPrefManager.getUrl());
        }

    }
    private fun updateCredentials(username: String, password: String) {
        try {
            sharedPrefManager.saveUsername(username.toString());
            sharedPrefManager.savePassword(password.toString());
            Toast.makeText(this@SettingScreen, "Settings Saved!", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this@SettingScreen, "failed to Saved!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun copyPath(path: String) {
        try {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("path", path)
            clipboard.setPrimaryClip(clip)
            Toast.makeText(this@SettingScreen, "Url copied!", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this@SettingScreen, "Failed to copy!", Toast.LENGTH_SHORT).show()
        }


    }


}