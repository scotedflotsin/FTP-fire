package com.example.ftp_fire.ServerSetup

data class FTPServerConfig(
    var username: String = "admin",
    var password: String = "password",
    var port: Int = 2121,
    var folderPath: String = "/storage/emulated/0/"
)
