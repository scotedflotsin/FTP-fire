package com.example.ftp_fire.Utils

import android.content.Context
import android.content.SharedPreferences

class SharedPrefManager(context: Context) {

    private val sharedPreferences: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    private val editor: SharedPreferences.Editor = sharedPreferences.edit()

    companion object {
        private const val PREF_NAME = "FTPSettings"
        private const val KEY_PORT = "port"
        private const val KEY_USERNAME = "username"
        private const val KEY_PASSWORD = "password"
        private const val KEY_RUNNING_STATUS = "running_status"
        private const val KEY_URL = "url"
        private const val KEY_PATH = "path"
    }

    // Save or update a value for Port
    fun savePort(port: Int) {
        editor.putInt(KEY_PORT, port)
        editor.apply()
    }

    // Save or update a value for Username
    fun saveUsername(username: String) {
        editor.putString(KEY_USERNAME, username)
        editor.apply()
    }

    // Save or update a value for Password
    fun savePassword(password: String) {
        editor.putString(KEY_PASSWORD, password)
        editor.apply()
    }

    // Save or update a value for Running Status
    fun saveRunningStatus(runningStatus: Boolean) {
        editor.putBoolean(KEY_RUNNING_STATUS, runningStatus)
        editor.apply()
    }

    // Save or update a value for URL
    fun saveUrl(url: String) {
        editor.putString(KEY_URL, url)
        editor.apply()
    }

    // Save or update a value for Path
    fun savePath(path: String) {
        editor.putString(KEY_PATH, path)
        editor.apply()
    }

    // Get Port value
    fun getPort(): Int {
        return sharedPreferences.getInt(KEY_PORT, 21) // Default to port 21 if not set
    }

    // Get Username value
    fun getUsername(): String {
        return sharedPreferences.getString(KEY_USERNAME, "") ?: ""
    }

    // Get Password value
    fun getPassword(): String {
        return sharedPreferences.getString(KEY_PASSWORD, "") ?: ""
    }

    // Get Running Status
    fun getRunningStatus(): Boolean {
        return sharedPreferences.getBoolean(KEY_RUNNING_STATUS, false)
    }

    // Get URL value
    fun getUrl(): String {
        return sharedPreferences.getString(KEY_URL, "") ?: ""
    }

    // Get Path value
    fun getPath(): String {
        return sharedPreferences.getString(KEY_PATH, "") ?: ""
    }
}
