import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.util.Log
import android.widget.Toast
import com.example.ftp_fire.ServerSetup.FTPServerConfig
import org.apache.ftpserver.FtpServer
import org.apache.ftpserver.FtpServerFactory
import org.apache.ftpserver.listener.ListenerFactory
import org.apache.ftpserver.usermanager.ClearTextPasswordEncryptor
import org.apache.ftpserver.usermanager.impl.BaseUser
import org.apache.ftpserver.usermanager.PropertiesUserManagerFactory
import org.apache.ftpserver.usermanager.impl.WritePermission
import java.net.InetAddress
/** Main server class
 * Note: Please do not make any change if you're not an expert
 * */
class FTPServerManager(private val context: Context, private val config: FTPServerConfig) {

    private var ftpServer: FtpServer? = null

    // Start or restart the FTP server with the updated port and path
    fun startServer(): String? {
        if (!isWiFiConnected()) {
            Log.e("FTPServerManager", "WiFi is not connected. Please connect to a WiFi network.")
            Toast.makeText(context, "WiFi is not connected. Please connect to a WiFi network.", Toast.LENGTH_LONG).show()
            return null
        }

        try {
            // Stop the previous server instance if it's running
            stopServer()

            val serverFactory = FtpServerFactory()

            // Configure the listener with the new port
            val listenerFactory = ListenerFactory()
            listenerFactory.port = config.port
            serverFactory.addListener("default", listenerFactory.createListener())

            // Set up the user with permissions
            val user = BaseUser().apply {
                name = config.username
                password = config.password
                homeDirectory = config.folderPath
                authorities = listOf(WritePermission()) // Set write permissions
            }

            // Add the user to the server
            val userManager = serverFactory.userManager
            userManager.save(user)

            // Start the server with the new configuration
            ftpServer = serverFactory.createServer()
            ftpServer?.start()

            // Return the URL to access the server
            val ipAddress = getDeviceIpAddress()
            return if (ipAddress != null) {
                "ftp://$ipAddress:${config.port}"
            } else {
                Log.e("FTPServerManager", "Failed to get device IP address.")
                null
            }

        } catch (e: Exception) {
            Log.e("FTPServerManager", "Error starting FTP server: ${e.message}", e)
            Toast.makeText(context, "Error starting FTP server: ${e.message}", Toast.LENGTH_LONG).show()
            return null
        }
    }

    // Stop the FTP server
    fun stopServer() {
        if (ftpServer != null) {
            ftpServer?.stop()
            ftpServer = null
            Log.d("FTPServerManager", "FTP server stopped successfully.")
            Toast.makeText(context, "FTP server stopped successfully.", Toast.LENGTH_SHORT).show()
        }
    }

    // Check if WiFi is connected
    fun isWiFiConnected(): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivityManager.activeNetwork
        val networkCapabilities = connectivityManager.getNetworkCapabilities(network)
        return networkCapabilities?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
    }

    // Get the device's local IP address
    private fun getDeviceIpAddress(): String? {
        val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val ipAddress = wifiManager.connectionInfo.ipAddress
        return if (ipAddress != 0) {
            InetAddress.getByAddress(
                byteArrayOf(
                    (ipAddress and 0xFF).toByte(),
                    ((ipAddress shr 8) and 0xFF).toByte(),
                    ((ipAddress shr 16) and 0xFF).toByte(),
                    ((ipAddress shr 24) and 0xFF).toByte()
                )
            ).hostAddress
        } else {
            null
        }
    }

    // Update user configuration (useful for changing paths or user settings)
    fun updateUserConfiguration(serverFactory: FtpServerFactory, config: FTPServerConfig) {
        try {
            val userManager = serverFactory.userManager

            if (userManager.doesExist(config.username)) {
                userManager.delete(config.username) // Ensure the old user is removed
                Log.d("FTPServerManager", "Existing user ${config.username} deleted")
            }

            val user = BaseUser().apply {
                name = config.username
                password = config.password
                homeDirectory = config.folderPath
                authorities = listOf(WritePermission()) // Set the necessary permissions
            }

            userManager.save(user)
            Log.d("FTPServerManager", "User ${config.username} updated successfully")

        } catch (e: Exception) {
            Log.e("FTPServerManager", "Error updating user configuration: ${e.message}")
        }
    }
}
