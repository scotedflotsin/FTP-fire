package com.example.ftp_fire

import FTPServerManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.util.Log
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.ftp_fire.databinding.ActivityMainBinding
import java.net.URLDecoder

import androidx.documentfile.provider.DocumentFile
import com.example.ftp_fire.ServerSetup.FTPServerConfig
import com.example.ftp_fire.Utils.NotificationHelper
import com.example.ftp_fire.Utils.SharedPrefManager
import org.apache.ftpserver.FtpServerFactory
import org.apache.ftpserver.usermanager.ClearTextPasswordEncryptor
import org.apache.ftpserver.usermanager.impl.BaseUser
import java.io.File


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var ftpServerManager: FTPServerManager
    private lateinit var config: FTPServerConfig
    private var status: Boolean = false;
    private lateinit var notificationHelper: NotificationHelper
    private lateinit var sharedPrefManager: SharedPrefManager
    private var requestUrl = "fts://00.000.000";

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        enableEdgeToEdge()
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        // Initialize NotificationHelper
        notificationHelper = NotificationHelper(this@MainActivity)
        sharedPrefManager = SharedPrefManager(this@MainActivity)

        // Check and request notification permission if needed
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    android.Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                // Request the permission
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),
                    330
                )
            }
        }
        // Request permissions
        requestPermission()
        // Initialize configuration
        try {
            if (sharedPrefManager.getUsername().toString() == "" && sharedPrefManager.getPassword()
                    .toString() == ""
            ) {
                saveSettings();
            }
        } catch (e: Exception) {
            //Ignore error...
        }

        // Button click to open folder picker
        binding.startserver.setOnClickListener {

            //validating folder path
            var path = verifyStoragePath(this@MainActivity, binding.selectfolder.text.toString());

            if (status) {
                stopFtpServer(); //stopping server there
                binding.indicator.setBackground(
                    ContextCompat.getDrawable(
                        this@MainActivity,
                        R.drawable.rounded_indicator_bg
                    )
                )
                binding.startserver.setText("Start Server")
                status = false
                sharedPrefManager.saveUrl(requestUrl);
                notificationHelper.showNotification(
                    "FTP Server Stopped",
                    "The FTP server has been stopped."
                )

            } else {
                if (path == 1) {
                    Log.d("testing123", "path is valid");
                    //Now finally moving on to start server to share folder.
                    // Start the FTP server and get the access URL
                    config = FTPServerConfig(
                        username = sharedPrefManager.getUsername().toString(),
                        password = sharedPrefManager.getPassword().toString(),
                        port = 2124,
                        folderPath = binding.selectfolder.text.toString()
                    )
                    // Initialize FTP server manager with context
                    ftpServerManager = FTPServerManager(this, config)
                    logWiFiDetails();
                    val serverFactory = FtpServerFactory()

                    // Update the user configuration with the new details
                    ftpServerManager.updateUserConfiguration(serverFactory, config)
                    val url = startFTPServer()
                    url?.let {
                        Toast.makeText(this, "FTP Server started.", Toast.LENGTH_LONG)
                            .show()
                        status = true
                        binding.indicator.setBackground(
                            ContextCompat.getDrawable(
                                this@MainActivity,
                                R.drawable.rounded_indicator_green
                            )
                        );
                        binding.startserver.setText("Stop Server")
                        Log.d("testing123", "FTP Server started. Access it at: $it");
                        // Show server started notification
                        sharedPrefManager.saveUrl(url);
                        notificationHelper.showNotification(
                            "FTP Server Started..",
                            "Running on: $url"
                        )


                    } ?: run {
                        Toast.makeText(this, "Failed to start FTP Server", Toast.LENGTH_SHORT)
                            .show()
                    }
                } else {
                    Toast.makeText(this@MainActivity, "Path is not valid!", Toast.LENGTH_SHORT)
                        .show();
                }
            }


        }
        binding.picfolder.setOnClickListener {
            openFolderPicker()
        }
        binding.details.setOnClickListener {
            showDetails();
        }
    }

    private fun requestPermission() {
        val permissions = mutableListOf<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Request the new media-specific permissions for Android 13 and above
            permissions.add(android.Manifest.permission.READ_MEDIA_IMAGES)
            permissions.add(android.Manifest.permission.READ_MEDIA_VIDEO)
            permissions.add(android.Manifest.permission.READ_MEDIA_AUDIO)
            permissions.add(android.Manifest.permission.POST_NOTIFICATIONS)
        } else {
            // For older versions, request general storage permissions
            permissions.add(android.Manifest.permission.READ_EXTERNAL_STORAGE)
            permissions.add(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }

        val permissionsToRequest = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (permissionsToRequest.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, permissionsToRequest.toTypedArray(), 200)
        }
    }

    // Handle the user's response to permission requests
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        when (requestCode) {
            330 -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Notification permission granted
                    Toast.makeText(this, "Notification permission granted", Toast.LENGTH_SHORT)
                        .show()
                } else {
                    // Notification permission denied
                    Toast.makeText(this, "Notification permission denied", Toast.LENGTH_SHORT)
                        .show()
                }
            }

            200 -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Folder access permission granted
                    Toast.makeText(this, "Folder access permission granted", Toast.LENGTH_SHORT)
                        .show()
                } else {
                    // Folder access permission denied
                    Toast.makeText(
                        this,
                        "Permission denied. Cannot access folders.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    private fun openFolderPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        }
        // Launch the folder picker to allow the user to select a folder
        startActivityForResult(intent, PICK_FOLDER_REQUEST_CODE)
    }


// Function to convert a URI to a file path (simplified for context)


    // Handle the result when the user selects a folder
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == PICK_FOLDER_REQUEST_CODE && resultCode == RESULT_OK) {
            data?.data?.also { uri ->
                // Access the folder URI and convert it to a path if possible
                val folderPath = getPathFromTreeUri(this@MainActivity, uri)
                if (folderPath != null) {
                    // Process the folder path or use it for further operations
                    Log.d("test123", folderPath)
                    binding.selectfolder.setText(folderPath)
                } else {
                    Toast.makeText(this, "Unable to access folder.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun getPathFromTreeUri(context: Context, uri: Uri): String? {
        if (DocumentsContract.isTreeUri(uri)) {
            val documentId = DocumentsContract.getTreeDocumentId(uri)
            val split = documentId.split(":")
            val type = split[0]

            return if ("primary".equals(type, ignoreCase = true)) {
                // Return the path in primary storage
                "/storage/emulated/0/" + split.getOrNull(1)
            } else {
                // Handle other types of storage
                "/storage/${type}/" + split.getOrNull(1)
            }
        } else {
            // Handle other URI types if needed
            return null
        }
    }

    fun getFolderPathFromUri(context: Context, uri: Uri): String? {
        // Check if the URI is a tree URI (folder URI)
        if (DocumentsContract.isTreeUri(uri)) {
            try {
                // Convert URI to DocumentFile
                val documentFile = DocumentFile.fromTreeUri(context, uri)

                // Check if the URI is valid and is a directory
                if (documentFile != null && documentFile.isDirectory) {
                    // You can get the absolute path, but it depends on the Android version
                    // If you're on Android 10 (API 29) or higher, you should use the DocumentFile API to access the files.
                    return documentFile.uri.toString()  // or perform any specific operation on DocumentFile
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        return null
    }

    fun handleUriForAPI30AndAbove(uri: Uri): String? {
        try {
            // Android 11+ uses Storage Access Framework to get file paths
            val decodedUri = URLDecoder.decode(uri.toString(), "UTF-8")
            // Assuming it's accessing external storage (like SD card or USB)
            if (uri.toString().contains("primary")) {
                return "/storage/emulated/0" // Default path for primary storage
            } else if (uri.toString().contains("sdcard")) {
                // Handle SD card or other external storage
                return "/storage/SDCARD"  // Example path for SD card
            }
            return null
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    companion object {
        private const val PICK_FOLDER_REQUEST_CODE = 1
    }

    fun showDetails() {
        try {
            val intent = Intent(this@MainActivity, SettingScreen::class.java);
            startActivity(intent);
        } catch (e: Exception) {
            //Ignore error.....
        }

    }

    fun verifyStoragePath(context: Context, path: String): Int {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val directory = context.getExternalFilesDir(path) ?: return 2 // Return 2 on error
            if (directory.exists() && directory.isDirectory && directory.canRead() && directory.canWrite()) {
                Log.d("testing123", "Storage path is valid: ${directory.absolutePath}")
                return 1
            } else {
                Log.d("testing123", "Error: Issues with directory access.")
                return 2
            }
        } else {
            if (ContextCompat.checkSelfPermission(
                    context,
                    android.Manifest.permission.READ_EXTERNAL_STORAGE
                ) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(
                    context,
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    context as android.app.Activity,
                    arrayOf(
                        android.Manifest.permission.READ_EXTERNAL_STORAGE,
                        android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                    ),
                    1001
                )
                Log.d("testing123", "Permissions not granted. Requesting permissions.")
                return 2
            }

            val storagePath =
                if (path.startsWith("/")) path else "${Environment.getExternalStorageDirectory().absolutePath}/$path"
            val file = File(storagePath)
            Log.d("testing123", "Evaluating path: $storagePath")
            Log.d(
                "testing123",
                "Exists: ${file.exists()}, isDirectory: ${file.isDirectory}, canRead: ${file.canRead()}, canWrite: ${file.canWrite()}"
            )
            return if (file.exists() && file.isDirectory && file.canRead() && file.canWrite()) {
                Log.d("testing123", "Storage path is valid: $storagePath")
                1
            } else {
                when {
                    !file.exists() -> Log.d("testing132", "Error: Path does not exist.")
                    !file.isDirectory -> Log.d("testing132", "Error: Path is not a directory.")
                    !file.canRead() || !file.canWrite() -> Log.d(
                        "testing132",
                        "Error: Insufficient permissions to read/write at the path."
                    )
                }
                2 
            }
        }
    }

    private fun startFTPServer(): String? {
        return try {
            ftpServerManager.startServer()
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }


    override fun onDestroy() {
        super.onDestroy()
        // Stop the FTP server and reset the server instance to null
        ftpServerManager.stopServer()
        Toast.makeText(this, "FTP Server stopped", Toast.LENGTH_SHORT).show()
    }

    fun logWiFiDetails() {
        val wifiManager = this@MainActivity.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val wifiInfo: WifiInfo? = wifiManager.connectionInfo

        // Log basic WiFi info
        if (wifiInfo != null) {
            Log.d("WiFiStatus", "SSID: ${wifiInfo.ssid}")
            Log.d("WiFiStatus", "IP Address: ${wifiInfo.ipAddress}")
            Log.d("WiFiStatus", "WiFi is connected: ${wifiInfo.networkId != -1}")
        } else {
            Log.d("WiFiStatus", "No WiFi connection found")
        }
    }

    fun updateUserConfiguration(serverFactory: FtpServerFactory, config: FTPServerConfig) {
        try {
            // Initialize the password encryptor
            val passwordEncryptor = ClearTextPasswordEncryptor()
            val propertiesUserManagerFactory =
                org.apache.ftpserver.usermanager.PropertiesUserManagerFactory().apply {
                    this.passwordEncryptor = passwordEncryptor
                }

            // Get or create the user manager
            val userManager =
                serverFactory.userManager ?: propertiesUserManagerFactory.createUserManager()
            serverFactory.userManager = userManager

            // Attempt to delete the existing user configuration if it exists
            try {
                userManager.delete(config.username)
                Log.d("FTPServerSetup", "User ${config.username} deleted successfully")
            } catch (e: Exception) {
                Log.e("FTPServerSetup", "Error deleting user: ${e.message}")
            }

            // Create a new user with the updated configuration
            val user = BaseUser().apply {
                name = config.username
                password = config.password
                homeDirectory = config.folderPath
            }

            // Save the new user configuration
            userManager.save(user)
            Log.d("FTPServerSetup", "User ${config.username} updated successfully")

        } catch (e: Exception) {
            Log.e("FTPServerSetup", "Error updating user configuration: ${e.message}")
        }
    }

    // Function to stop the FTP server
    private fun stopFtpServer() {
        ftpServerManager.stopServer()
    }

    private fun saveSettings() {
        try {
            val username = "admin"
            val password = "123456"

            // Save each value individually
            sharedPrefManager.saveUsername(username)
            sharedPrefManager.savePassword(password)
            sharedPrefManager.saveUrl(requestUrl.toString())

            //  Toast.makeText(this, "Settings saved successfully", Toast.LENGTH_SHORT).show()
        } catch (e: NumberFormatException) {
            Toast.makeText(this, "Invalid port number", Toast.LENGTH_SHORT).show()
        }
    }

}


